package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import databaseOp.DatabaseOperations;

/**
 * Servlet implementation class editClientController
 */
@WebServlet("/editClientController")
public class editClientController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JOptionPane optionPane;
	 JFrame frame;
	 private DatabaseOperations dao;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public editClientController() {
        super();
        // TODO Auto-generated constructor stub
        optionPane= new JOptionPane();
        frame=new JFrame();
        dao = new DatabaseOperations();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("running do get of edit client Controller");
		RequestDispatcher view = request.getRequestDispatcher("/2clients.jsp");
		view.forward(request, response);		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("running do post of edit client Controller");
		int n = JOptionPane.showConfirmDialog(null,"Are you sure you would like to edit this record?","An Inane Question",JOptionPane.YES_NO_OPTION);

	
		System.out.println(n);
		
		
		String clientName=request.getParameter("name");
		String address=request.getParameter("address");
		String currency=request.getParameter("currency");
		String id=request.getParameter("id");
		System.out.println("id parameter--"+id+"");
		int idNum=Integer.parseInt(id);
		
		System.out.println(clientName+"-"+address+"-"+currency+"-value of n= "+n+" id= "+id);
		if(n==0){
			System.out.println("n=0 "+clientName);
			dao.editClient(idNum,clientName, address, currency);
			RequestDispatcher view1 = request.getRequestDispatcher("/2clients.jsp");
			view1.forward(request, response);
		}
		else if(n==1){
		
		RequestDispatcher view1 = request.getRequestDispatcher("/2clients.jsp");
		view1.forward(request, response);
		}
	}


}
