package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
	
import databaseOp.DatabaseOperations;


/**
 * Servlet implementation class editResourceController
 */
@WebServlet("/editResourceController")
public class editResourceController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	JOptionPane optionPane;
	 JFrame frame;
	 private DatabaseOperations dao;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public editResourceController() {
        super();
        // TODO Auto-generated constructor stub
        optionPane= new JOptionPane();
        frame=new JFrame();
        dao = new DatabaseOperations();

    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("running do get of edit resource Controller");
		RequestDispatcher view = request.getRequestDispatcher("/2resources.jsp");
		view.forward(request, response);		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("running do post of edit resources Controller");
		int n = JOptionPane.showConfirmDialog(null,"Are you sure you would like to edit this record?","An Inane Question",JOptionPane.YES_NO_OPTION);

		System.out.println(n);
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		String email=request.getParameter("email");
		String department=request.getParameter("department");
		String billRate=request.getParameter("brate");
		String costRate=request.getParameter("crate");
		String permission=request.getParameter("permission");
		String id=request.getParameter("id");
		System.out.println("value of string id from controller"+id);
		int idNum=Integer.parseInt(id);
		
		System.out.println(fname+"-"+lname+"-"+email+"-"+department+"-"+billRate+"-"+costRate+"-"+permission+"- value of id=" +idNum);
		
		
		
		if(n==0){
			System.out.println("n=0 "+fname);
			dao.editResources(idNum,fname, lname, email, department, billRate, costRate, permission);
			RequestDispatcher view1 = request.getRequestDispatcher("/2resources.jsp");
			view1.forward(request, response);
		}
		else if(n==1){
		
		RequestDispatcher view1 = request.getRequestDispatcher("/2resources.jsp");
		view1.forward(request, response);
		}
	}


} 

